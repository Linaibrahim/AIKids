package com.example.taskkids;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    FirebaseFirestore db;
    DocumentReference documentRef ,documentRefGrade,getDocumentRefMathGrade,getDocumentRefScienceGrade;
    double total=0;
    EditText nameFirst,nameSec,age,gradeMath,gradeScience;
    Button save;
    TextView salary;
    static double salaryN=0.0;
    int countStudent=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = FirebaseFirestore.getInstance();
        nameFirst=findViewById(R.id.first);
        nameSec=findViewById(R.id.last);
        age=findViewById(R.id.age);
        gradeMath=findViewById(R.id.mathG);
        gradeScience=findViewById(R.id.scienceG);
        save=findViewById(R.id.save);
        salary=findViewById(R.id.salary);


        documentRef  = db.collection("students").document("student"+countStudent);
        documentRefGrade  = db.document("students/student"+countStudent+"/grades/subjects");
//        getDocumentRefMathGrade= db.document("students/student8/grades/subjects/math");
       save.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(nameFirst.getText()!=null){

               }
               Map<String,Object> data=new HashMap<String,Object>();
               Map<String,Object> dataGrades=new HashMap<String,Object>();
               data.put("age",age.getText().toString());
               data.put("fullName",nameFirst.getText().toString()+" "+nameSec.getText().toString());
               dataGrades.put("math",Double.valueOf( gradeMath.getText().toString()));
               dataGrades.put("science",Double.valueOf( gradeScience.getText().toString()));
               documentRef.set(data).addOnCanceledListener(new OnCanceledListener() {
                   @Override
                   public void onCanceled() {
                       Log.i("great job","yes");
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Log.i("error","no");
                   }
               });
               ////////////////////////////
               documentRefGrade.set(dataGrades).addOnCanceledListener(new OnCanceledListener() {
                   @Override
                   public void onCanceled() {
                       Log.i("great job","yes");
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Log.i("error","no");
                   }
               });

               documentRefGrade.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                   @Override
                   public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                       if (task.isSuccessful()) {
                           DocumentSnapshot document = task.getResult();
                           if (document.exists()) {
                               double mathGrade = document.getDouble("math");
                               double scienceGrade = document.getDouble("science");
                               total =mathGrade+scienceGrade;
                               Log.d("getData", "DocumentSnapshot data: " + total);
                               //ss[0] =document.getData().values().toString();
                               //Log.d("getData", "DocumentSnapshot data: " + ss[0]);
                           } else {
                               Log.d("noData", "No such document");
                           }
                       } else {
                           Log.d("failed", "get failed with ", task.getException());
                       }
                   }
               });

               if(total<=190){
                   salaryN=500;
               }else {
                   salaryN=300;
               }

               data.put("salary",salaryN);
               documentRef.set(data).addOnCanceledListener(new OnCanceledListener() {
                   @Override
                   public void onCanceled() {
                       Log.i("great job","yes");

                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Log.i("error","no");
                   }
               });
               Log.i("salary  12",salaryN+"");
               salary.setText(String.valueOf(salaryN));
               countStudent++;
           }
       });


    }

}
